#include "veins/modules/application/ieee80211p/BaseWaveApplLayer.h"

class MySimpleApp : public BaseWaveApplLayer {
protected:
    virtual void onWSM(WaveShortMessage* wsm) override {
        EV << "Received a message: " << wsm->getWsmData() << endl;
    }

    virtual void handleSelfMsg(cMessage* msg) override {
        if (msg->isName("sendMsg")) {
            WaveShortMessage* wsm = new WaveShortMessage();
            wsm->setWsmData("Hello from Veins");
            sendDown(wsm);
            scheduleAt(simTime() + 1, msg); // 每秒发送一次消息
        } else {
            BaseWaveApplLayer::handleSelfMsg(msg);
        }
    }

    virtual void initialize(int stage) override {
        BaseWaveApplLayer::initialize(stage);
        if (stage == 0) {
            scheduleAt(simTime() + 1, new cMessage("sendMsg"));
        }
    }
};
Define_Module(MySimpleApp);
